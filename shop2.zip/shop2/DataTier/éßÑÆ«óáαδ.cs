﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;

namespace DataTier
{
    public class ВсеТовары
    {
        public static void СохранитьВсеТоварыTxt(List<Товар> товары, string path)
        {
            using (StreamWriter writer = new StreamWriter(path, false, Encoding.UTF8))
            {
                foreach (var товар in товары)
                {
                    writer.WriteLine($"{товар.Наименование}/{товар.Цена}/{товар.Количество}/{товар.Магазин}");
                }
            }
        }

        public static void СохранитьВсеТоварыJson(List<Товар> товары, string path)
        {
            string jsonString = JsonSerializer.Serialize(товары, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(path, jsonString, Encoding.UTF8);
        }

        public static List<Товар> ПолучитьВсеТоварыИзФайла()
        {
            List<Товар> list = new List<Товар>();

            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
            {
                string filePath = openFileDialog.FileName;
                string extension = Path.GetExtension(filePath).ToLower();

                if (extension == ".json")
                {
                    string json = File.ReadAllText(filePath, Encoding.UTF8);
                    list = JsonSerializer.Deserialize<List<Товар>>(json);
                }
                else
                {
                    using (StreamReader sreader = new StreamReader(filePath, Encoding.UTF8))
                    {
                        while (!sreader.EndOfStream)
                        {
                            string[] line = sreader.ReadLine().Split("/");

                            Товар tovar = new Товар()
                            {
                                Наименование = line[0].Trim(),
                                Цена = float.Parse(line[1].Trim()),
                                Количество = int.Parse(line[2].Trim()),
                                Магазин = line[3].Trim(),
                            };
                            list.Add(tovar);
                        }
                    }
                }
            }

            return list;
        }
    }
}
