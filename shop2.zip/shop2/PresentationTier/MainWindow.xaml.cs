﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using DataTier;
using LogicTier;
using Microsoft.Win32;
using Newtonsoft.Json;

namespace PresentationTier
{
    public partial class MainWindow : Window
    {
        private Магазин магазин;
        private string selectedFilePath;
        private List<ТоварнаяПозиация> текущиеТовары = new();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_open_file_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "JSON файлы (*.json)|*.json";
            if (openFileDialog.ShowDialog() == true)
            {
                string json = File.ReadAllText(openFileDialog.FileName);

                List<Товар> товары = Newtonsoft.Json.JsonConvert.DeserializeObject<List<Товар>>(json);
                List<ТоварнаяПозиация> товарыДляМагазина = товары.Select(t => new ТоварнаяПозиация(t)).ToList();

                // ВАЖНО: без Магазин перед магазин
                магазин = new Магазин(товарыДляМагазина);
                текущиеТовары = товарыДляМагазина; // Чтобы текущие товары тоже обновились

                this.DataContext = магазин;
                MainList.ItemsSource = магазин.СписокТоваров;
                ОбновитьСредниеЦены();
            }
        }

        private void btn_add_item_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Names.Text) ||
                string.IsNullOrWhiteSpace(Price.Text) ||
                string.IsNullOrWhiteSpace(Colvo.Text) ||
                Shops.SelectedItem == null)
            {
                MessageBox.Show("Пожалуйста, заполните все поля для добавления.");
                return;
            }

            if (!float.TryParse(Price.Text, out float цена) || цена <= 0)
            {
                MessageBox.Show("Цена должна быть положительным числом.");
                return;
            }

            if (!int.TryParse(Colvo.Text, out int количество) || количество <= 0)
            {
                MessageBox.Show("Количество должно быть положительным целым числом.");
                return;
            }

            string магазинНазвание = ((ComboBoxItem)Shops.SelectedItem).Content.ToString();

            var товар = new ТоварнаяПозиация(new Товар
            {
                Наименование = Names.Text,
                Цена = цена,
                Количество = количество,
                Магазин = магазинНазвание
            });

            текущиеТовары.Add(товар);

            магазин = new Магазин(текущиеТовары);
            this.DataContext = магазин;
            MainList.ItemsSource = null;
            MainList.ItemsSource = магазин.СписокТоваров;

            ОбновитьСредниеЦены();

            Names.Clear();
            Price.Clear();
            Colvo.Clear();
            Shops.SelectedIndex = -1;
        }

        private void btn_save_file_Click(object sender, RoutedEventArgs e)
        {
            if (текущиеТовары.Count == 0)
            {
                MessageBox.Show("Нет товаров для сохранения.");
                return;
            }

            Microsoft.Win32.SaveFileDialog saveFileDialog = new()
            {
                Filter = "Text files (*.txt)|*.txt|JSON files (*.json)|*.json|All files (*.*)|*.*",
                Title = "Выберите файл для сохранения"
            };

            if (saveFileDialog.ShowDialog() == true)
            {
                selectedFilePath = saveFileDialog.FileName;

                string extension = System.IO.Path.GetExtension(selectedFilePath).ToLower();

                if (extension == ".json")
                {
                    var товарыДляСохранения = текущиеТовары.Select(p => new Товар
                    {
                        Наименование = p.НаименованиеТовара,
                        Цена = p.ЦенаТовара,
                        Количество = p.КоличествоТовара,
                        Магазин = p.Магазин
                    }).ToList();

                    string jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(товарыДляСохранения, Newtonsoft.Json.Formatting.Indented);
                    File.WriteAllText(selectedFilePath, jsonString, Encoding.UTF8);
                }
                else
                {
                    ВсеТовары.СохранитьВсеТоварыTxt(текущиеТовары.Select(p => new Товар
                    {
                        Наименование = p.НаименованиеТовара,
                        Цена = p.ЦенаТовара,
                        Количество = p.КоличествоТовара,
                        Магазин = p.Магазин
                    }).ToList(), selectedFilePath);
                }

                MessageBox.Show("Товары сохранены!");
            }
        }

        private void btn_del_file_Click(object sender, RoutedEventArgs e)
        {
            var selectedItem = MainList.SelectedItem as ТоварнаяПозиация;
            if (selectedItem != null)
            {
                MessageBoxResult result = MessageBox.Show(
                    $"Вы уверены, что хотите удалить товар '{selectedItem.НаименованиеТовара}'?",
                    "Подтверждение удаления",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning
                );

                if (result == MessageBoxResult.Yes)
                {
                    текущиеТовары.Remove(selectedItem);
                    магазин = new Магазин(текущиеТовары);
                    this.DataContext = магазин;
                    MainList.ItemsSource = null;
                    MainList.ItemsSource = магазин.СписокТоваров;

                    ОбновитьСредниеЦены();
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите товар для удаления.");
            }
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (Shops.SelectedItem != null)
            {
                var selectedItem = (ComboBoxItem)Shops.SelectedItem;
                MessageBox.Show($"Выбрано: {selectedItem.Content}");
            }
        }

        private void ОбновитьСредниеЦены()
        {
            try
            {
                if (магазин == null)
                {
                    MessageBox.Show("Магазин не инициализирован.");
                    return;
                }

                var средниеЦены = магазин.ПолучитьСредниеЦеныПоМагазинам();
                if (средниеЦены == null || !средниеЦены.Any())
                {
                    MessageBox.Show("Нет данных о средних ценах.");
                    return;
                }

                var средниеЦеныФорматированные = средниеЦены
                    .Select(pair => new
                    {
                        Магазин = pair.Key,
                        СредняяЦена = Math.Round(pair.Value, 2)
                    }).ToList();

                // Пример: Привязка данных на UI
                dgAveragePrices.ItemsSource = средниеЦеныФорматированные;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при обновлении средних цен: {ex.Message}");
            }
        }

        private void btn_search_file_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Сначала выбираем файл
                OpenFileDialog openFileDialog = new OpenFileDialog
                {
                    Filter = "JSON Files (*.json)|*.json"
                };

                if (openFileDialog.ShowDialog() != true)
                {
                    return;
                }

                string json = File.ReadAllText(openFileDialog.FileName, Encoding.UTF8);

                // Теперь спрашиваем ключ для поиска
                string ключ = Microsoft.VisualBasic.Interaction.InputBox(
                    "Введите ключ для поиска в JSON:",
                    "Поиск значения",
                    ""
                );

                if (string.IsNullOrWhiteSpace(ключ))
                {
                    MessageBox.Show("Ключ не введён.", "Ошибка");
                    return;
                }

                // Список для хранения найденных значений
                List<string> найденныеЗначения = new List<string>();

                using var document = JsonDocument.Parse(json);
                JsonElement root = document.RootElement;

                if (root.ValueKind == JsonValueKind.Array)
                {
                    // Если корень — массив, ищем в каждом объекте массива
                    foreach (var элемент in root.EnumerateArray())
                    {
                        if (элемент.ValueKind == JsonValueKind.Object && элемент.TryGetProperty(ключ, out JsonElement значение))
                        {
                            найденныеЗначения.Add(значение.ToString());
                        }
                    }

                    if (найденныеЗначения.Count == 0)
                    {
                        MessageBox.Show($"Ключ '{ключ}' не найден в массиве.", "Информация");
                    }
                    else
                    {
                        // Если что-то нашли — показываем
                        string всеЗначения = string.Join("\n", найденныеЗначения);
                        MessageBox.Show($"Найденные значения для ключа '{ключ}':\n{всеЗначения}", "Результат поиска");
                    }
                }
                else
                {
                    MessageBox.Show("Ожидался JSON-массив в корне.", "Ошибка");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка поиска: " + ex.Message, "Ошибка");
            }

        }
    }
}
