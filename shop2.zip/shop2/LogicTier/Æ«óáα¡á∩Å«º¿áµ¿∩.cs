﻿using DataTier;

namespace LogicTier
{
    public class ТоварнаяПозиация
    {
        private Товар _товар;

        public ТоварнаяПозиация(Товар p)
        {
            _товар = p;
        }
        public string НаименованиеТовара
        {
            get { return _товар.Наименование; }
            set { _товар.Наименование = value; }
        }
        public float ЦенаТовара
        {
            get { return _товар.Цена; }
            set { _товар.Цена = value; }
        }
        public int КоличествоТовара
        {
            get { return _товар.Количество; }
            set { _товар.Количество = value; }
        }
        public string Магазин
        {
            get { return _товар.Магазин; }
            set { _товар.Магазин = value; }
        }
        public float СуммарнаяСтоимостьПозиции
        {
            get { return _товар.Цена * _товар.Количество; }
        }
        public string ПредставлениеТовара
        {
            get
            {
                return $"{_товар.Наименование} ({_товар.Количество} x {_товар.Цена}₽ = {СуммарнаяСтоимостьПозиции}₽) - {_товар.Магазин}";
            }

        }
    }
}