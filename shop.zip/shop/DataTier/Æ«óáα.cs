﻿namespace DataTier
{
    public class Товар
    {
        public String Наименование { get; set; }
        public float Цена { get; set; }
        public int Количество { get; set; }
        public string Магазин { get; set; }
        public float Сумма => Цена * Количество;
        public string ПредставлениеТовара => $"{Наименование} ({Количество} x {Цена}₽)";
    }
}