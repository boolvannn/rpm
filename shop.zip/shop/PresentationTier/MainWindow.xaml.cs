﻿using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DataTier;
using LogicTier;
using Microsoft.Win32;

namespace PresentationTier;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    private Магазин магазин;

    public MainWindow()
    {
        InitializeComponent();
    }

    private void btn_open_file_Click(object sender, RoutedEventArgs e)
    {
        SaveFileDialog sfd = new SaveFileDialog();
        sfd.Filter = "Текстовые файлы(*.txt)|*.txt|Скрипты(*.sql)|*.sql|Документы(*.docx)|*.docx";
        if (sfd.ShowDialog() == true)
        {
            string FilePath = sfd.FileName;
            StreamWriter swriter = new StreamWriter(FilePath);

            var магазин = (LogicTier.Магазин)DataContext;

            //проходим по всем товарам магазина и сохраняем их 
            foreach (var товарнаяПозиация in магазин.СписокТоваров)
            {
                //записываем представление товара в файлик наш (перезаписываем или создаём новый)
                swriter.WriteLine(товарнаяПозиация.ПредставлениеТовара);
            }
            //если подтвердил сохранение - сообщение об выполнении 
            swriter.Close();
            MessageBox.Show($"Данные сохранены в файл {FilePath}");
        }
        else
        { //если отменил - сообщение об отказе
            MessageBox.Show("Пользователь отказался от окна сохранения");
        }
    }

    private string selectedFilePath;
    private void btn_save_file_Click(object sender, RoutedEventArgs e)
    {
        Microsoft.Win32.SaveFileDialog saveFileDialog = new Microsoft.Win32.SaveFileDialog();
        saveFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
        saveFileDialog.Title = "Выберите файл для сохранения";

        if (saveFileDialog.ShowDialog() == true)
        {
            selectedFilePath = saveFileDialog.FileName;
            MessageBox.Show($"Файл выбран: {selectedFilePath}");
        }
        string Наименование = Names.Text;
        string Цена = Price.Text;
        string Количество = Colvo.Text;
        string Магазин = Shops.Text;

        // Проверяем, что все поля заполнены
        if (string.IsNullOrWhiteSpace(Наименование) ||
            string.IsNullOrWhiteSpace(Цена) ||
            string.IsNullOrWhiteSpace(Количество) ||
            string.IsNullOrWhiteSpace(Магазин))
        {
            MessageBox.Show("Пожалуйста, заполните все поля.");
            return;
        }
        string строкаДляЗаписи = $"{Наименование}/{Цена}/{Количество}/{Магазин}";

        File.AppendAllText(selectedFilePath, строкаДляЗаписи + Environment.NewLine);

        MessageBox.Show("Рейс успешно сохранен!");

        Names.SelectedIndex = -1;
        Price.Clear();
        Colvo.Clear();
        Shops.Clear();
    }
    private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (Names.SelectedItem != null)
        {
            var selectedItem = (System.Windows.Controls.ComboBoxItem)Names.SelectedItem;
            MessageBox.Show($"Выбрано: {selectedItem.Content}");
        }
    }
}
