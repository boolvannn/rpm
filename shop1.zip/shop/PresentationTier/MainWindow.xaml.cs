﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using DataTier;
using LogicTier;

namespace PresentationTier;

public partial class MainWindow : Window
{
    private Магазин магазин;
    private string selectedFilePath;

    public MainWindow()
    {
        InitializeComponent();
    }

    private void btn_open_file_Click(object sender, RoutedEventArgs e)
    {
        List<Товар> товарыИзФайла = ВсеТовары.ПолучитьВсеТоварыИзФайла();

        if (товарыИзФайла.Count == 0)
        {
            MessageBox.Show("Нет товаров в файле!");
            return;
        }

        List<ТоварнаяПозиация> позиции = new List<ТоварнаяПозиация>();
        foreach (var t in товарыИзФайла)
        {
            позиции.Add(new ТоварнаяПозиация(t));
        }

        магазин = new Магазин(позиции);
        this.DataContext = магазин;

        var средниеЦены = магазин.ПолучитьСредниеЦеныПоМагазинам()
            .Select(pair => new
            {
                Магазин = pair.Key,
                СредняяЦена = pair.Value
            }).ToList();

        dgAveragePrices.ItemsSource = средниеЦены;
    }

    private void btn_save_file_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(Names.Text) ||
            string.IsNullOrWhiteSpace(Price.Text) ||
            string.IsNullOrWhiteSpace(Colvo.Text) ||
            Shops.SelectedItem == null)
        {
            MessageBox.Show("Пожалуйста, заполните все поля.");
            return;
        }

        // Проверка, что цена и количество — положительные числа
        if (!double.TryParse(Price.Text, out double цена) || цена <= 0)
        {
            MessageBox.Show("Цена должна быть положительным числом.");
            return;
        }

        if (!int.TryParse(Colvo.Text, out int количество) || количество <= 0)
        {
            MessageBox.Show("Количество должно быть положительным целым числом.");
            return;
        }

        // Выбор файла, если еще не был выбран
        if (string.IsNullOrWhiteSpace(selectedFilePath))
        {
            Microsoft.Win32.SaveFileDialog saveFileDialog = new Microsoft.Win32.SaveFileDialog
            {
                Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*",
                Title = "Выберите файл для сохранения"
            };
            if (saveFileDialog.ShowDialog() == true)
            {
                selectedFilePath = saveFileDialog.FileName;
                MessageBox.Show($"Файл выбран: {selectedFilePath}");
            }
            else
            {
                return;
            }
        }

        string строкаДляЗаписи = $"{Names.Text}/{Price.Text}/{Colvo.Text}/{((ComboBoxItem)Shops.SelectedItem).Content}";
        File.AppendAllText(selectedFilePath, строкаДляЗаписи + Environment.NewLine);

        MessageBox.Show("Товар сохранен!");

        Names.Clear();
        Price.Clear();
        Colvo.Clear();
        Shops.SelectedIndex = -1;
    }

    private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (Shops.SelectedItem != null)
        {
            var selectedItem = (ComboBoxItem)Shops.SelectedItem;
            MessageBox.Show($"Выбрано: {selectedItem.Content}");
        }
    }

    private void btn_del_file_Click(object sender, RoutedEventArgs e)
    {
        var selectedItem = MainList.SelectedItem as Товар;
        if (selectedItem != null)
        {
            
            MessageBox.Show("Удаление пока не реализовано.");
        }
        else
        {
            MessageBox.Show("Пожалуйста, выберите товар для удаления.");
        }
    }
}
